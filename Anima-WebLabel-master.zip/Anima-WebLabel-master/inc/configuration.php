<?php

# Image path to be used in the HTML client
$IMAGE_WEB_DIR = "../data/images";

# Image path for internal PHP use
$IMAGE_ROOT_DIR  = "../data/images";
$ANNOTATIONS_DIR = "../data/annotations";

# Collection name 
$COLLECTION_NAME = "collection_01";

# Not annotated image 80% to be presented to user
$ratio_new_old = 80;

?>